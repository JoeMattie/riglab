# Handoff: RigLab Editor Overhaul ("Floating Glass" layout)

## Overview

A UI/UX overhaul of the RigLab sketch editor (repo: `JoeMattie/riglab`). The chosen direction replaces the stacked toolbar/panel chrome with a **full-bleed canvas and floating pill panels**: a labeled tool pill on the left, project/mechanism chip top-left, actions chip top-right, transport pill bottom-center, and a DOF/conflicts pill bottom-right. Element properties appear **contextually on the canvas** (dimension chips on pipes, joint popovers on nodes, a small selection card docked beside the selection) instead of a permanent inspector.

Key UX changes vs. the current app:

1. **Pipe lengths are directly manipulable**: hover shows length, drag endpoint shows live readout with snapping, click the label to type an exact value, drag the label to scrub it, and a lock chip pins the length.
2. **Joint types are one click away**: clicking any node opens a popover (Pivot / Weld / Slider / Anchor / Detach) at the node; the same popover serves as the snap-connect menu when a drawn pipe lands on geometry.
3. **Joint kinds get distinct canvas glyphs**: pivot = ring, weld = filled square, slider = rounded slot, anchor = filled diamond, bound-to-skeleton = green ring. (Today pivots and welds are indistinguishable.)
4. **DOF stops being a mystery number**: the conflicts pill expands into a list of concrete conflicts, each with a one-click fix and click-to-zoom.

## About the Design Files

The files in this bundle are **design references created in HTML** — interactive prototypes showing intended look and behavior, **not production code to copy directly**. The task is to recreate these designs inside the riglab codebase's existing environment: **Vite + React + TypeScript, Zustand stores (`appStore`, `editorStore`), Konva canvas (`SketchCanvas.tsx`), and the shadcn/ui + Tailwind adoption already planned for Phase 3**. Reuse the existing solver, docOps, snapping, and viewTransform modules — this overhaul is chrome + interaction, not engine work.

The `.dc.html` files open directly in a browser (keep `support.js` next to them). They are the spec; the React implementation should use shadcn primitives (Popover, DropdownMenu, Toggle, Button, Badge, Tooltip) styled to match.

## Fidelity

- **`RigLab Editor Hi-fi.dc.html` — high-fidelity.** Colors, typography, spacing, radii, shadows, and copy are final; recreate pixel-perfectly with the codebase's libraries. Several interactions are live in the file: tool switching, length chip → inline edit (Enter commits), length lock toggle, joint node → popover → glyph change, DOF pill expand, mechanism menu, Sketch/Design toggle, gravity/forces chips, play/pause.
- **`Wireframes.dc.html` — low-fidelity.** Round-1 explorations. Options 1e/1f are the approved interaction storyboards (length editing, joint popovers) and are normative for behavior; 1a/1b/1d were rejected layouts, kept for context.
- **`Current UI.dc.html`** — reference recreation of the app as it is today (for before/after comparison only).

## Screens / Views

### Editor (single screen, hi-fi)

Full-viewport canvas; all chrome floats above it. Base: background `#fcfcfd`, text `#1a1d24`, font `IBM Plex Sans` 13.5px; numerics use `IBM Plex Mono` 500.

**Floating panel style (shared):** background `#fff`, border `1px solid #e4e4e7`, radius `12px` (pills 14px), shadow `0 4px 16px rgba(20,24,40,.08)` (menus/popovers: `0 12px 32px rgba(20,24,40,.16)`). Margin from viewport edges: `16px`.

#### 1. Canvas (full bleed)
- Grid: 0.1 m lines `#ededf2` 1px; world axes `#c8c8d4` 1px. Grid density follows the existing adaptive rule in `SketchCanvas.tsx`.
- Wearer silhouette: `#b9c0cc`, 2.5px, round joins (unchanged from current renderer).
- Pipes: `#324` 5px round caps; selected pipe `#d80` 5.5px with white endpoint handles (r9, 3px `#d80` stroke); conflict members `#d22`.
- Ropes `#557` dashed `4 4` 2px; elastic zigzag `#2a8a4a` 2.5px (existing `zigzag()` helper, 6px amplitude); binding leaders `#4a4` dashed `3 5` 1.5px.
- Node glyphs: pivot = white circle r7.5 with `#28d` 3px ring; weld = 14px filled `#324` square; slider = 30×16 rounded slot, `#28d` 3px stroke; anchor = 18px filled `#222` diamond (45° square); bound = ring in `#2a2`; plain end node = filled `#28d` dot r5.5. Interactive node hotspot gets a soft halo `0 0 0 4px rgba(34,136,221,.15)`.

#### 2. Tool pill (left, top 88px)
Width 158px, padding 8px, rows 100% width. Row: icon 16×16 (1.7px stroke, `currentColor`) + label 13px + shortcut key right-aligned (`IBM Plex Mono` 10.5px). Groups with uppercase captions (`10px`, letter-spacing `.09em`, color `#a1a1aa`, padding `8px 8px 3px`):
- (no caption): Select / pose — `V`
- **Draw**: Pipe `P`, Polyline `L`, Freehand `F`
- **Forces**: Rope `R`, Elastic `E`, Bowden `B`, Torsion `T`
- **Wearer**: Bind `N`

States: active row `background:#e9f1fb; color:#1d5fb8; font-weight:500` (kbd `#7ba4d6`); inactive transparent, icon `#52525b`, kbd `#c4c4cc`; hover `#f4f4f5`. Radius 8px, padding `6px 8px`. Tooltips carry the existing `Toolbar.tsx` title strings.

#### 3. Project chip (top-left)
Back arrow (`#71717a`) · divider (`1px × 18px #e4e4e7`) · project name 600 · mechanism switcher button (`#fafafa` bg, border `#e4e4e7`, radius 8, "Mechanism 1 side-left ▾", view name in `#a1a1aa`) · saved indicator (7px dot + "saved", `#3d9950`, 12px).
Mechanism menu (below, width 230): active row `#e9f1fb`/`#1d5fb8` with view label right; hover `#f4f4f5`; divider; "+ New mechanism…" in `#2a78d6`.

#### 4. Actions chip (top-right)
Undo `↶` / redo `↷` (`#52525b`) · divider · Sketch/Design segmented control (track `#f4f4f5` radius 8 padding 2; active segment white, radius 6, shadow `0 1px 3px rgba(20,24,40,.12)`, 500; inactive text `#71717a`) · divider · units `in/lb` (mono 12px `#71717a`) · Export ▾ (bordered button, radius 8).

#### 5. Dimension chips (on canvas, per pipe)
- **Unlocked (selected pipe):** white chip, border `1.5px #d80`, radius 14, padding `4px 12px`, text `IBM Plex Mono` 12.5px `#b46a00`, e.g. `27.9 in`. Cursor `ew-resize` (drag = scrub). Adjacent 26px circular lock button (white, border `#e4e4e7`, gray lock icon).
- **Editing:** chip swaps to `2px #d80` border, inline `<input>` (52px, mono), suffix `in ⏎` in `#a1a1aa`. Enter/Esc/blur commits.
- **Locked (boom pipe):** solid `#2a78d6` chip, white lock glyph + value, shadow `0 2px 8px rgba(42,120,214,.3)`; lock button turns solid blue.

#### 6. Joint popover (at clicked node)
Width 178, padding 6, radius 12. Header `JOINT · NODE 12` (10.5px uppercase `#a1a1aa`). Rows: glyph (14×14, same canvas glyph language) + label; current row `#e9f1fb`/`#1d5fb8` with trailing ✓; hover `#f4f4f5`; Detach uses a gray ✕ glyph. Options: Pivot, Weld, Slider, Anchor, Detach.
Same component doubles as the **snap-connect menu** when a drawn pipe end lands on a node/pipe (default choice = Pivot, committed on Enter; Esc cancels) — replaces `ConnectMenu.tsx`.

#### 7. Selection card (docked beside selection)
Width 216. Header: 9px `#d80` swatch square + "Pipe · link #7" (600 13px) + ✕ (`#a1a1aa`). Rows (label `#71717a` left, control right): Length → mono value in `#f4f4f5` chip + lock button; End A → "● pivot ▾" chip (opens joint popover); End B → "■ weld ▾". Footer: `Split` `Reverse` (`#2a78d6`) … `Delete` (`#c33`), 12.5px, top border `#f0f0f2`. Card is draggable/pinnable (not implemented in mock).

#### 8. Transport pill (bottom-center)
Clip chip ("head-bob ▾", `#fafafa` bg) · 30px round play button (`#1a1d24`, white ▶/❚❚) · scrubber 210px (track 4px `#e9e9ee`, progress `#2a78d6`, 14px white thumb with 2px `#2a78d6` ring) · time `0:01.5 / 0:04.0` (mono 11.5px `#71717a`) · divider · `1.0×` and `amp 100%` scrub labels (mono, cursor ew-resize) · divider · toggle chips **gravity** / **forces** (on: `#e9f1fb`/`#1d5fb8` + ✓; off: `#f4f4f5`/`#71717a`) · "inputs (2) ▾" chip (opens input-channel popover — sliders + locks per channel, reusing `ForcesPanel.tsx` logic).

#### 9. DOF pill (bottom-right)
- Conflicts: white pill, border `1.5px #e9a4a4`, text `#b32` 500, 8px `#d33` dot, "DOF 8 · 5 conflicts ▴". Click expands a 300px card (border `#f2c4c4`) listing each conflict: element (500 12.5px) + issue (`#71717a` 12px) + fix action (`#2a78d6`, e.g. "unlock a length ▸"); row hover `#fdf3f3`; clicking a row zooms the canvas to the offending element.
- Healthy: border `#b5d6b9`, text `#2b7237`, dot `#3d9950`, "DOF 8 · mechanism".

## Interactions & Behavior

- **Tools**: single-key shortcuts (V P L F R E B T N). Esc returns to Select and cancels drafts (existing behavior). Drawing behaviors (click-drag pipe, polyline double-click finish, rope waypoints/eyelets, bowden two-stroke, torsion two-pivot pick) are unchanged — see `SketchCanvas.tsx`.
- **Length editing** (storyboard 1f in `Wireframes.dc.html`):
  1. Hover any pipe → faint length tag.
  2. Drag an endpoint → live readout chip, dashed ghost of prior pose, snap ticks at ½ in increments + node/grid snaps (reuse `snapping.ts`; display via `unitsPreference`).
  3. Click the tag → inline numeric field; Enter commits (one undo entry), Esc cancels.
  4. Drag the tag horizontally → scrub value; click lock → length pinned (chip goes solid blue); locked lengths are held as constraints while posing.
- **Joints**: click node → popover; choosing a type re-realizes the joint via `docOps.setNodeKind`/element ops; double-click node still toggles anchor. Drawing onto geometry opens the same popover with Pivot preselected (Enter = accept, Esc = detach-cancel).
- **Selection**: click element → selection card + `#d80` highlight; shift/cmd-click multi-select (card shows shared props); click empty canvas clears; Delete removes selection (one undo entry).
- **Popover dismissal**: click anywhere on canvas closes menus (canvas mousedown), Esc likewise.
- **Pan/zoom**: unchanged — wheel pan, ctrl+wheel / pinch zoom, two-finger touch (`gesture.ts`, `viewTransform.ts`). Floating chrome must not swallow these events (pills stop propagation of clicks only).
- **Transitions**: popovers/menus 120ms ease-out fade+2px rise; chip lock state 150ms; no other animation.

## State Management

Extends the existing `editorStore` (Zustand):

- `tool` (existing) — driven by the tool pill + shortcuts.
- `selectedElementIds` (existing) — drives selection card + chips.
- `openPopover: null | {kind:'joint', nodeId} | {kind:'connect', pending} | {kind:'mech'} | {kind:'dof'} | {kind:'inputs'}` — one popover at a time.
- `lengthEdit: null | {elementId, draft: string}` — inline field state.
- Locked lengths live on the **document** (per-element `lengthLocked: boolean` via `docOps` + schema migration) so they undo/redo and persist.
- `face`, `playback`, `equilibriumOn`, gravity — existing; the transport pill and chips are re-skins of `TransportBar.tsx` + `ForcesPanel.tsx` state.
- Conflict list derives from `dof`/`violated` diagnostics already in the store; "fix" actions map to docOps (unlock length, merge pivots, etc.).

## Design Tokens

Colors — chrome: bg `#fcfcfd`; panel `#fff`; borders `#e4e4e7` (hairline `#f0f0f2`); text `#1a1d24`; muted `#71717a`; faint `#a1a1aa`; accent `#2a78d6`; accent tint `#e9f1fb`; accent text `#1d5fb8`; success `#3d9950`; danger text `#b32`/`#c33`, danger border `#e9a4a4`, danger tint `#fdf3f3`.
Colors — canvas (from `SketchCanvas.tsx`, unchanged): pipe `#324`, selected `#d80`, violated `#d22`, node `#28d`, bound `#2a2`, rope `#557`, elastic `#2a8a4a`, bowden `#8a5cd0`, torsion `#c0459a`, silhouette `#b9c0cc`, grid `#ededf2`/`#c8c8d4`, anchor `#222`.
Type: IBM Plex Sans 400/500/600 (UI 13.5px base; captions 10–10.5px uppercase, ls .07–.09em); IBM Plex Mono 500 for all numerics/kbd (10.5–12.5px).
Radii: panels 12, pills/chips 14, rows/buttons 8, small chips 6. Spacing: 16px viewport margins; 8px panel padding; rows `6px 8px`.
Shadows: panel `0 4px 16px rgba(20,24,40,.08)`; menu `0 12px 32px rgba(20,24,40,.16)`; locked chip `0 2px 8px rgba(42,120,214,.3)`.

## Assets

No image assets. All icons are inline SVG (16×16, 1.7px stroke, currentColor) drawn in the hi-fi file — port them as React components or swap for lucide equivalents where a match exists (lock, play, pause). Fonts: IBM Plex Sans + IBM Plex Mono via Google Fonts (self-host for offline requirement).

## Files

- `RigLab Editor Hi-fi.dc.html` — **the spec.** Hi-fi interactive mock (open in a browser; keep `support.js` beside it).
- `Wireframes.dc.html` — round-1 wireframes; 1e/1f are the normative interaction storyboards.
- `Current UI.dc.html` — recreation of today's UI for comparison.
- `support.js` — runtime for the `.dc.html` files (not part of the design).

Repo touchpoints: `src/ui/EditorShell.tsx` (layout → floating chrome), `src/ui/editor/Toolbar.tsx` (→ tool pill), `MechanismTabs.tsx` (→ mech menu), `ConnectMenu.tsx` (→ joint popover), `TransportBar.tsx` + `ForcesPanel.tsx` (→ transport pill), `infopanel/*` (→ selection card), `SketchCanvas.tsx` (glyphs, chips, hover tags), `src/state/editorStore.ts`, `src/state/docOps.ts` + `src/schema/` (length locks).
